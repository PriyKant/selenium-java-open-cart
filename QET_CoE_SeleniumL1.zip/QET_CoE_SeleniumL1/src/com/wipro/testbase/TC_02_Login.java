package com.wipro.testbase;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

import com.wipro.utilities.PropertyReader;

import jxl.read.biff.BiffException;

public class TC_02_Login {
	
	static String  url;
	public  static WebDriver driver;
	public static void main(String[] args) throws FileNotFoundException, IOException, BiffException, InterruptedException {
		// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver", "resourses//driverfiles//chromedriver.exe");

	driver = new ChromeDriver();	
	
	PropertyReader admi = new PropertyReader();
	url = admi.readkar("url");
	
	driver.get(url);
	
	driver.manage().window().maximize();


		
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();

				

		ExcelParser obj = new ExcelParser("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\testdeta\\Registration.xls",1);
		String[][] myData = obj.retriveData();
		
		driver.findElement(By.xpath( "//*[@id='input-email']")).sendKeys(myData[1][0]);
		
		driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys(myData[1][1]);
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")).click();
		
File file = new File("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\logout.txt");
		
		file.createNewFile();
		
		String p2 = driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]")).getText();
		
		
		FileWriter fw1 = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\logout.txt");


		fw1.write(p2);
		fw1.close();

}
}