package com.wipro.testbase;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.wipro.utilities.PropertyReader;

import jxl.read.biff.BiffException;

public class TC_05_NewsLetter {
	
	static String  url;

public static WebDriver driver;
	public static void main(String[] args) throws FileNotFoundException, IOException, BiffException, InterruptedException {
	
		System.setProperty("webdriver.chrome.driver","resourses//driverfiles//chromedriver.exe");
	     driver = new ChromeDriver();

	 
	 PropertyReader admi = new PropertyReader();
	 url = admi.readkar("url");
	
	driver.get(url);
	

        driver.manage().window().maximize();


		
	driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();

			

	ExcelParser obj = new ExcelParser("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\testdeta\\Registration.xls",4);
	String[][] myData = obj.retriveData();
	
	driver.findElement(By.xpath( "//*[@id='input-email']")).sendKeys(myData[1][0]);
	
	driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys(myData[1][1]);
	
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	Thread.sleep(1000);

	driver.findElement(By.xpath("//*[@id=\"column-right\"]/div/a[12]")).click();
	driver.findElement(By.xpath("//input[@name = \"newsletter\"and @value = \"0\"]")).click();
	driver.findElement(By.xpath("//input[@type = \"submit\"]")).click();
	
String p4 = driver.findElement(By.xpath("//*[@id=\"account-account\"]/div[1]")).getText();
 FileWriter fw3 = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\Success.txt");
 fw3.write("\n"+ p4);
 fw3.flush();
 fw3.close();
 
 driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[1]")).click();
   driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")).click();
   

	String p5 = driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]")).getText();
	
	
	FileWriter fw5 = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\logout.txt");


	fw5.write("/n"+p5);
	fw5.flush();
	fw5.close();
 
	}

}
