package com.wipro.testbase;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
//import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileReader {
	public  static WebDriver driver;
	static String  url;

	public  static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "resourses//driverfiles//chromedriver.exe");

		driver = new ChromeDriver();	

		Properties prop1 = new Properties();
		prop1.load(new FileInputStream("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\config\\config.properties"));
		driver.get(prop1.getProperty("url"));
		

	   
	     

	}

}
