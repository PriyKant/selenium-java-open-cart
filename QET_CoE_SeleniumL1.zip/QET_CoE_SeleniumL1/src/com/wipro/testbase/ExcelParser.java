package com.wipro.testbase;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ExcelParser {
	private String filepath;
	private int Sheet;
	
	public ExcelParser(String filepath,int sh)
	{
		this.filepath=filepath;
		this.Sheet=sh;	
	}
public String[][] retriveData()throws IOException,FileNotFoundException,BiffException{
	File myfile=new File(filepath);
	Workbook objwork=Workbook.getWorkbook(myfile);
	Sheet objsheet=objwork.getSheet(Sheet);
	
	int c=objsheet.getColumns();
	int r=objsheet.getRows();
	
	String[][] parameter=new String[c][r];
	
	int row,col;
	for(row=0;row<r;row++)
		for(col=0;col<c;col++)
	{
	        Cell objcell=objsheet.getCell(col,row);
	       parameter[col][row]=objcell.getContents();
	      // System.out.println(parameter[col][row]);
	}
	
	return parameter;
}
	
	
}


