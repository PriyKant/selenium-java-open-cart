package com.wipro.testbase;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.htmlunit.javascript.host.file.FileReader;
import com.wipro.utilities.PropertyReader;

import jxl.read.biff.BiffException;

public class TC_03_PasswordChange {
	
	static String  url;
	public  static WebDriver driver;
	
	public static void main(String[] args) throws FileNotFoundException, IOException, BiffException, InterruptedException {
		// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver", "resourses//driverfiles//chromedriver.exe");

	driver = new ChromeDriver();	
	
	PropertyReader admi = new PropertyReader();
	url = admi.readkar("url");
	
	driver.get(url);
	
	driver.manage().window().maximize();


		
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();

				

		ExcelParser obj = new ExcelParser("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\testdeta\\Registration.xls",2);
		String[][] myData = obj.retriveData();
		
		driver.findElement(By.id( "input-email")).sendKeys(myData[1][0]);
		
		driver.findElement(By.id("input-password")).sendKeys(myData[1][1]);
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		//change password
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='column-right']/div/a[3]")).click();
	
		driver.findElement(By.id("input-password")).sendKeys(myData[1][2]);
		driver.findElement(By.id("input-confirm")).sendKeys(myData[1][2]);

		

	driver.findElement(By.xpath("//*[@id='content']/form/div/div[2]/input")).click();
	
	
	//BufferedReader reader = new BufferedReader(new FileReader("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\Success.txt"));
//	File pwordchange=new File("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\Success.txt");

	//System.out.println(encyptFile.canRead());

	String p3 = driver.findElement(By.xpath("//*[@id=\"account-account\"]/div[1]")).getText();
	
	
	FileWriter fw1 = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\Success.txt", true);
	fw1.write("\n"+p3);
	fw1.flush();
	fw1.close();

	
	}
	}
