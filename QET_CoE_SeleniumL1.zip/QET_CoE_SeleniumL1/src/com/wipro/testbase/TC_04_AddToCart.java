package com.wipro.testbase;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.wipro.utilities.PropertyReader;
import jxl.read.biff.BiffException;


public class TC_04_AddToCart {
		static String  url;
	    public  static WebDriver driver;
	
	    public static void main(String[] args) throws FileNotFoundException, IOException, BiffException, InterruptedException {
		// TODO Auto-generated method stub
	     System.setProperty("webdriver.chrome.driver", "resourses//driverfiles//chromedriver.exe");

      	driver = new ChromeDriver();	
	
	   PropertyReader admi = new PropertyReader();
	   url = admi.readkar("url");
	
	  driver.get(url);
	
	  driver.manage().window().maximize();


		
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")).click();

				

		ExcelParser obj = new ExcelParser("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\testdeta\\Registration.xls",3);
		String[][] myData = obj.retriveData();
		Thread.sleep(1000);
		driver.findElement(By.xpath( "//*[@id='input-email']")).sendKeys(myData[1][0]);
		
		driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys(myData[1][1]);
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		Actions a = new Actions(driver);
		a.moveToElement(driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[3]/a"))).build().perform();
		driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();
		
		
		// Take screenshot and store as a file format
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
		
		FileUtils.copyFile(src, new File("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\ScreenShot.png"));
		}
	
		catch (IOException e) {
			e.printStackTrace();
		
	}
		driver.findElement(By.xpath("//select[@id=\"input-sort\"]")).click();
		driver.findElement(By.xpath("//select[@id=\"input-sort\"]/option[4]")).click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[1]/div/div[2]/div[1]/h4/a")).click();
        driver.findElement(By.xpath("//input[@type =\"radio\" and @name=\"option[218]\" and @value=\"5\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"input-option223\"]/div[1]/label/input")).click();
        
        //
       
        driver.findElement(By.xpath("//*[@id=\"input-option208\"]")).sendKeys(myData[1][2]);
        driver.findElement(By.xpath("//*[@id=\"input-option217\"]/option[2]")).click();

        driver.findElement(By.xpath("//*[@id=\"input-option209\"]")).sendKeys(myData[1][3]);

        
        driver.findElement(By.xpath("//*[@id=\"button-upload222\"]")).click();
       
        Thread.sleep(1000);
       // Runtime.getRuntime().exec("C:\\Users\\pr392467\\Desktop\\priy.pal@wipro.com\\FileUpload.exe");
        Runtime.getRuntime().exec("resourses//testdeta//UploadFile.exe"+" "+System.getProperty("user.dir")+"\\resourses\\testdeta\\apple.jpg");

        new WebDriverWait(driver, 4).until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().accept(); 
        
        driver.findElement(By.xpath("//*[@id=\"product\"]/div[7]/div/span/button")).click();
	
        driver.findElement(By.id("input-option219")).clear();
        driver.findElement(By.id("input-option219")).sendKeys(myData[1][4]);
        
        driver.findElement(By.id("input-option221")).clear();
        driver.findElement(By.id("input-option221")).sendKeys(myData[1][5]);

        driver.findElement(By.id("input-option220")).clear();
        driver.findElement(By.id("input-option220")).sendKeys(myData[1][6]);
        
              driver.findElement(By.xpath("//*[@id=\"input-quantity\"]")).clear();
       driver.findElement(By.xpath("//*[@id=\"input-quantity\"]")).sendKeys(myData[1][7]);
       
       driver.findElement(By.xpath("//button[@id=\"button-cart\"]")).click();
       Thread.sleep(1000);
     String p3 = driver.findElement(By.xpath("//div[@class=\"alert alert-success alert-dismissible\"]")).getText();
     
     FileWriter fw1 = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\Success.txt", true);
     fw1.write("\n" +p3);
     fw1.flush();
     fw1.close();
    
     driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[4]/a/span")).click();
 
     // Take screenshot and store as a file format
  		File src1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
  		try {
  		
  		FileUtils.copyFile(src1, new File("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\ScreenShot2.png"));
  		}
  	
  		catch (IOException e) {
  			e.printStackTrace();
  		
  	}

  		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/table/tbody/tr/td[4]/div/input")).clear();
  		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/table/tbody/tr/td[4]/div/input")).sendKeys("2");
  		driver.findElement(By.xpath("//i[@class=\"fa fa-refresh\"]")).click();
  		driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[2]/a")).click();
  		
  		String p4 = driver.findElement(By.xpath("//*[@id=\"checkout-cart\"]/div[1]")).getText();
  		FileWriter fw2 = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\Warning.txt", true);
  	     fw2.write("\n" +p4);
  	     fw2.flush();
  	     fw2.close();
  	     
  	     driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[1]")).click();
  	     driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")).click();
  	     

 		String p5 = driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]")).getText();
 		
 		
 		FileWriter fw = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\logout.txt");


 		fw.write(p5);
 		fw.close();
  	    
     	}
}
	