package com.wipro.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.wipro.utilities.PropertyReader;

import jxl.read.biff.BiffException;

//import jxl.Cell;
public class TC_01_Registration {
	
	static String  url;
	public  static WebDriver driver;
	
	public static void main(String[] args) throws FileNotFoundException, IOException, BiffException {
			// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver", "resourses//driverfiles//chromedriver.exe");

	driver = new ChromeDriver();	
	
	PropertyReader admi = new PropertyReader();
	 url = admi.readkar("url");
	
	driver.get(url);
	
	
	driver.manage().window().maximize();


		
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath("//a[@href='http://spezicoe.wipro.com:81/opencart1/index.php?route=account/register']")).click();

	

		ExcelParser obj = new ExcelParser("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\testdeta\\Registration.xls",0);
		String[][] myData = obj.retriveData();
		
		driver.findElement(By.id("input-firstname")).sendKeys(myData[1][0]);
		driver.findElement(By.id("input-lastname")).sendKeys(myData[1][1]);
		driver.findElement(By.id("input-email")).sendKeys(myData[1][2]);
		driver.findElement(By.id("input-telephone")).sendKeys(myData[1][3]);
		driver.findElement(By.id("input-password")).sendKeys(myData[1][4]);
		driver.findElement(By.id("input-confirm")).sendKeys(myData[1][5]);

		
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[2]")).click();
  
		String p1 = driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]")).getText();
		

		
		FileWriter fw = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\Success.txt");
		
		fw.write(p1);
		
		fw.close();
		
		
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")).click();
		
		File file = new File("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\logout.txt");
		
		file.createNewFile();
		
		String p2 = driver.findElement(By.xpath("//*[@id=\"content\"]/p[1]")).getText();
		
		
		FileWriter fw1 = new FileWriter("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\output_message\\logout.txt");


		fw1.write(p2);
		fw1.close();
	}

	
		
	

}
