package com.wipro.testcases;

public class Registration {

	public static void main(String[] args) {
		

	}

}
