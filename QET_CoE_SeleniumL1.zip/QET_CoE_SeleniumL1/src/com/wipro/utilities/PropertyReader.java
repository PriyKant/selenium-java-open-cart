package com.wipro.utilities;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {

	public String readkar(String isko) throws FileNotFoundException, IOException {

		Properties prop1 = new Properties();
		prop1.load(new FileInputStream("E:\\Priy\\E_Work\\WorkSpace_priy\\QET_CoE_SeleniumL1\\resourses\\config\\config.properties"));
	    return prop1.getProperty(isko);
	     

	}

}
